package main;

import timer.Timer;
import timer.TimerListener;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * slimon
 * 05.07.2014
 */
public class App {

    private static Timer timer;
    private static Gui gui;
    private static Sound sound;
    private static long time;
    private static boolean isAttacked = false;

    public static void main(String[] args) {
        //FileUtil.writeToFile("1.txt", HTTPUtil.getContentOfHTTPPage("http://blazar.ru/overview.php", "Windows-1251"), false);

        /*Thread.sleep(2000);
        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_F5);
        robot.keyRelease(KeyEvent.VK_F5);*/
        /*Color color = new Color(35, 223, 48);
        Thread.sleep(2000);
        ImageIO.write(ImageUtil.getScreenShot(), "png", new File("1.png"));
        System.out.println(ImageUtil.containsColor(ImageUtil.getScreenShot(), color));*/


        Options.load();
        sound = new Sound(new File("ALARM.WAV"));
        sound.setVolume(1F);

        /*int[] coords = getCoords();
        ImageIO.write(ImageUtil.getSubImage(ImageUtil.getScreenShot(), coords[0], coords[1], coords[2], coords[3]),
                "png", new File("1.png"));*/

        gui = new Gui("Blazar Utils v0.1 Beta", 350, 200, 500, 200, false);
        gui.init();
        //gui.pack();
        gui.setVisible(true);
    }

    private static boolean searchAttacks() {
        gui.timeLeft.setText("-");
        try {
            Robot robot = new Robot();
            robot.keyPress(KeyEvent.VK_F5);
            robot.keyRelease(KeyEvent.VK_F5);
            Thread.sleep(Integer.parseInt(Options.get("delayAfterRefresh")));
            BufferedImage image = ImageUtil.getScreenShot();
            boolean attack;
            if(Boolean.parseBoolean(Options.get("coordsEnabled"))) {
                int[] coords = getCoords();
                attack = ImageUtil.containsColors(image, getColors(), coords[0], coords[1], coords[2], coords[3]);
            } else {
                attack = ImageUtil.containsColors(image, getColors(), 0, 0, image.getWidth(), image.getHeight());
            }
            //FileUtil.writeToFile("log.txt", attack, true);
            if(attack) {
                isAttacked = true;
            }
            return attack;
        } catch (AWTException e) {
            onError(e);
        } catch (InterruptedException e) {
            onError(e);
        }
        return false;
    }

    public static void onError(Exception e) {
        String errLog =
                "### " + getDateAndTime() + "\n"
                + "A error has been detected\n\n"
                + "Error at " + e.getClass() + "\n"
                + "[STACK TRACE]\n";
        StackTraceElement[] trace = e.getStackTrace();
        for (StackTraceElement aTrace : trace) {
            errLog += ("    " + aTrace.toString() + "\n");
        }
        errLog += "[CAUSED BY]\n" + "    " + e.getCause() + "\n\n    " + e.getMessage();
        FileUtil.writeToFile("log.txt", errLog, true);
    }

    public static String getDateAndTime() {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/YY HH:mm:ss");
        Date date = new Date();
        return dateFormat.format(date);
    }

    private static void alert() {
        gui.timeLeft.setText("Тревога!!!");
        gui.timeLeft.setForeground(Color.RED);
        while(isAttacked) {
            if(!sound.isPlaying()) {
                sound.play();
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                onError(e);
            }
        }
    }

    public static boolean startObserve() {
        System.out.println("Starting observe...");
        timer = new Timer(1);
        timer.register(timerListener);

        Random rand = new Random(System.nanoTime());
        if(getRandTime() > 0) {
            time = getTime() + rand.nextInt(getRandTime()) - rand.nextInt(getRandTime());
        } else {
            time = getTime();
        }
        timer.start();
        return true;
    }

    public static boolean stopObserve() {
        System.out.println("Stopping observe...");
        timer.stopTimer();
        gui.timeLeft.setText("-");
        if(isAttacked) {
            isAttacked = false;
            sound.stop();
            gui.timeLeft.setForeground(Color.BLACK);
        }
        return true;
    }

    public static void saveSettings(String color, String time, String randTime, String coordsEnabled, String coords) {
        Options.set("color", color);
        Options.set("time", time);
        Options.set("randTime", randTime);
        Options.set("coordsEnabled", coordsEnabled);
        Options.set("coords", coords);
        Options.save();
    }

    private static Color[] getColors() {
        String[] rawRGB = Options.get("color").split("\\D+");
        int[][] RGB = new int[rawRGB.length/3][3];
        for(int i = 0; i < rawRGB.length; i++) {
            RGB[i/3][i%3] = Integer.parseInt(rawRGB[i]);
        }
        Color[] ret = new Color[rawRGB.length/3];
        for(int i = 0; i < ret.length; i++) {
            ret[i] = new Color(RGB[i][0], RGB[i][1], RGB[i][2]);
        }
        return ret;
    }

    private static int getRandTime() {
        return parseTimeToInt(Options.get("randTime"));
    }

    private static int getTime() {
        return parseTimeToInt(Options.get("time"));
    }

    private static int parseTimeToInt(String rawTime) {
        String[] rawTimes = rawTime.split("\\s+");
        int time = 0, num;
        for(String s : rawTimes) {
            num = Integer.parseInt(s.split("\\D+")[0]);
            if(s.contains("h") || s.contains("H")) {
                time += num * 60 * 60;
            } else if(s.contains("m") || s.contains("M")) {
                time += num * 60;
            } else {
                time += num;
            }
        }
        return time;
    }

    private static String parseIntToTime(int rawTime) {
        int h = rawTime / 3600;
        int m = (rawTime - h * 3600) / 60;
        int s = rawTime - h * 3600 - m * 60;
        return h + "h " + m + "m " + s + "s";
    }

    private static int[] getCoords() {
        String[] rawCoords = Options.get("coords").split("\\D+");
        int[] coords = new int[rawCoords.length];
        for(int i = 0; i < rawCoords.length; i++) {
            coords[i] = Integer.parseInt(rawCoords[i]);
        }
        return coords;
    }

    private static TimerListener timerListener = new TimerListener() {
        @Override
        public void onTick(long currentTick) {
            if(currentTick >= time) {
                timer.stopTimer();
                if(searchAttacks()) {
                    alert();
                } else {
                    startObserve();
                }
            } else {
                gui.timeLeft.setText(parseIntToTime((int) (time - currentTick)));
                //gui.timeLeft.setForeground(Color.BLACK);
            }
        }
    };
}
