package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * slimon
 * 05.07.2014
 */
public class Gui extends JFrame {

    JLabel timeLeft;

    public Gui(String title, int width, int height, int posX, int posY, boolean resizable) {
        super(title);
        setSize(width, height);
        setLocation(posX, posY);
        setResizable(resizable);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }

    public void init() {
        JPanel content = new JPanel();
        content.setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setEnabled(false);

        JPanel attackObserver = new JPanel();
        attackObserver.setLayout(new BoxLayout(attackObserver, BoxLayout.LINE_AXIS));

        JPanel settings = new JPanel();
        settings.setLayout(new BoxLayout(settings, BoxLayout.PAGE_AXIS));

        JPanel color = new JPanel();
        color.setLayout(new BoxLayout(color, BoxLayout.PAGE_AXIS));
        JLabel colorLabel = new JLabel("Цвета RGB:");
        final JTextField colorField = new JTextField();
        colorField.setMaximumSize(new Dimension(350, 20));
        colorField.setText(Options.get("color"));

        JPanel time = new JPanel();
        time.setLayout(new BoxLayout(time, BoxLayout.PAGE_AXIS));
        JLabel timeLabel = new JLabel("Интервал обновления:");
        JPanel timeFields = new JPanel();
        timeFields.setLayout(new BoxLayout(timeFields, BoxLayout.LINE_AXIS));
        final JTextField timeField = new JTextField();
        timeField.setMaximumSize(new Dimension(150, 20));
        timeField.setText(Options.get("time"));
        JLabel timeRandomLabel = new JLabel("+/-");
        final JTextField timeRandomField = new JTextField();
        timeRandomField.setMaximumSize(new Dimension(150, 20));
        timeRandomField.setText(Options.get("randTime"));

        JPanel coords = new JPanel();
        coords.setLayout(new BoxLayout(coords, BoxLayout.LINE_AXIS));
        JLabel coordsLabel = new JLabel("Область сканирования:");
        final JCheckBox coordsCheckBox = new JCheckBox();
        coordsCheckBox.setSelected(Boolean.parseBoolean(Options.get("coordsEnabled")));
        final JTextField coordsField = new JTextField();
        coordsField.setMaximumSize(new Dimension(350, 20));
        coordsField.setText(Options.get("coords"));
        coordsField.setEnabled(Boolean.parseBoolean(Options.get("coordsEnabled")));

        final JButton save = new JButton("Сохранить настройки");

        JPanel buttons = new JPanel();
        buttons.setLayout(new BoxLayout(buttons, BoxLayout.PAGE_AXIS));
        JLabel timeLeftLabel = new JLabel("Время до обновления:");
        timeLeft = new JLabel("-");
        final JButton start = new JButton("Начать");
        final JButton stop = new JButton("Остановить");
        start.setMaximumSize(stop.getMaximumSize());
        stop.setEnabled(false);

        JPanel ratingCalc = new JPanel();

        this.add(content);
        content.add(tabbedPane);

        tabbedPane.addTab("Оповещалка", attackObserver);

        attackObserver.add(settings);

        settings.add(color);
        color.add(colorLabel);
        color.add(colorField);

        settings.add(time);
        time.add(timeLabel);
        time.add(timeFields);
        timeFields.add(timeField);
        timeFields.add(timeRandomLabel);
        timeFields.add(timeRandomField);

        settings.add(coordsLabel);
        settings.add(coords);
        coords.add(coordsCheckBox);
        coords.add(coordsField);

        settings.add(save);

        attackObserver.add(buttons);

        buttons.add(timeLeftLabel);
        buttons.add(timeLeft);
        buttons.add(start);
        buttons.add(stop);

        //tabbedPane.addTab("Расчёт рейтинга", ratingCalc);

        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                App.saveSettings(colorField.getText(), timeField.getText(), timeRandomField.getText(),
                        coordsCheckBox.isSelected()+"", coordsField.getText());
            }
        });

        start.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                save.doClick();
                if(App.startObserve()) {
                    start.setEnabled(false);
                    stop.setEnabled(true);
                }
            }
        });

        stop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(App.stopObserve()) {
                    start.setEnabled(true);
                    stop.setEnabled(false);
                }
            }
        });

        coordsCheckBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                coordsField.setEnabled(coordsCheckBox.isSelected());
                //save.doClick();
            }
        });
    }
}
