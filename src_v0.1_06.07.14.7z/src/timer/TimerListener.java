package timer;

public interface TimerListener {
	
	public abstract void onTick(long currentTick);
}
